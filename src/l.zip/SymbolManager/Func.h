//
// Created by lyh on 10/13/2023.
//

#ifndef SYSY_COMPILER_FUNC_H
#define SYSY_COMPILER_FUNC_H

#include <vector>

class Func {
public:
    int retype;
    int paramNum;
    std::vector<int> paramTypeList;
    Func(int retype, int paramNum);
};


#endif //SYSY_COMPILER_FUNC_H