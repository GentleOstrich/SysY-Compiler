//
// Created by lyh on 10/13/2023.
//
#include "Func.h"
Func::Func(int retype, int paramNum) {
    this->retype = retype;
    this->paramNum = paramNum;
}